import React from 'react';

const SystemComputationSidebar = () => {
    return (
        <div>
            
        </div>
    );
}

export default SystemComputationSidebar;
