import { createSlice } from '@reduxjs/toolkit'

export const userSlice = createSlice({
    name: 'formula',
    initialState: {},
    reducers: {
        
    }
})
export const {  } = userSlice.actions

export default userSlice.reducer